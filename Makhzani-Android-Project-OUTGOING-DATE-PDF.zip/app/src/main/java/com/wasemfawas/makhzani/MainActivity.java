package com.wasemfawas.makhzani;

import android.app.*;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.*;
import android.widget.*;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db;
    LinearLayout page, itemsBox, historyBox;
    EditText nameInput, unitInput, qtyInput;
    Spinner typeSpinner;
    TextView totalText, dateButton;
    WebView pdfWebView;
    int movementYear, movementMonth, movementDay;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB();
        Calendar now = Calendar.getInstance();
        movementYear = now.get(Calendar.YEAR);
        movementMonth = now.get(Calendar.MONTH);
        movementDay = now.get(Calendar.DAY_OF_MONTH);
        buildUI();
        updateDateLabel();
        refresh();
    }

    int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }

    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size);
        t.setTextColor(0xFF17324D);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(4), dp(6), dp(4), dp(6));
        return t;
    }

    EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setSingleLine(true); e.setTextSize(16);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        return e;
    }

    Button button(String label) {
        Button b = new Button(this); b.setText(label);
        return b;
    }

    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(18), dp(16), dp(24));
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        page.setBackgroundColor(0xFFF4F7FA);
        scroll.addView(page);
        setContentView(scroll);

        TextView title = text("مخزني", 28, true);
        title.setTextColor(0xFF087E8B);
        page.addView(title);
        page.addView(text("إدارة الأصناف والكميات الداخلة والخارجة", 14, false));

        totalText = text("عدد الأصناف: 0", 18, true);
        totalText.setBackgroundColor(0xFFE1F3F2);
        totalText.setPadding(dp(12), dp(12), dp(12), dp(12));
        page.addView(totalText);

        page.addView(text("إضافة صنف جديد", 20, true));
        nameInput = input("اسم الصنف");
        unitInput = input("الوحدة (قطعة، كرتون، كيس، كيلو...)");
        page.addView(nameInput); page.addView(unitInput);
        Button saveItemButton = button("حفظ الصنف");
        saveItemButton.setOnClickListener(v -> addItem());
        page.addView(saveItemButton);

        page.addView(text("تسجيل حركة مخزنية", 20, true));
        typeSpinner = new Spinner(this);
        String[] types = {"وارد", "صادر"};
        typeSpinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, types));
        page.addView(typeSpinner);
        qtyInput = input("الكمية");
        page.addView(qtyInput);

        page.addView(text("تاريخ الحركة", 16, true));
        dateButton = text("", 17, true);
        dateButton.setGravity(Gravity.CENTER);
        dateButton.setBackgroundColor(0xFFE1F3F2);
        dateButton.setPadding(dp(12), dp(12), dp(12), dp(12));
        dateButton.setOnClickListener(v -> chooseDate());
        page.addView(dateButton);

        Button movementButton = button("تسجيل الحركة");
        movementButton.setOnClickListener(v -> addMovement());
        page.addView(movementButton);

        page.addView(text("الأصناف والأرصدة", 20, true));
        itemsBox = new LinearLayout(this);
        itemsBox.setOrientation(LinearLayout.VERTICAL);
        page.addView(itemsBox);
        Button refreshButton = button("تحديث القائمة");
        refreshButton.setOnClickListener(v -> refresh());
        page.addView(refreshButton);

        page.addView(text("سجل الحركات (الوارد والصادر)", 20, true));
        historyBox = new LinearLayout(this);
        historyBox.setOrientation(LinearLayout.VERTICAL);
        page.addView(historyBox);

        Button pdfButton = button("تصدير تقرير PDF");
        pdfButton.setOnClickListener(v -> exportPdf());
        page.addView(pdfButton);
    }

    void chooseDate() {
        DatePickerDialog dialog = new DatePickerDialog(this,
            (view, year, month, day) -> {
                movementYear = year; movementMonth = month; movementDay = day;
                updateDateLabel();
            }, movementYear, movementMonth, movementDay);
        dialog.show();
    }

    String selectedDate() {
        return String.format(Locale.US, "%04d-%02d-%02d", movementYear, movementMonth + 1, movementDay);
    }

    void updateDateLabel() {
        dateButton.setText("📅  " + String.format(Locale.US, "%02d/%02d/%04d",
            movementDay, movementMonth + 1, movementYear) + "  (اضغط لتغيير التاريخ)");
    }

    void addItem() {
        String name = nameInput.getText().toString().trim();
        String unit = unitInput.getText().toString().trim();
        if (name.isEmpty() || unit.isEmpty()) {
            toast("أدخل اسم الصنف والوحدة"); return;
        }
        if (db.findItem(name) != -1) { toast("هذا الصنف موجود بالفعل"); return; }
        db.addItem(name, unit);
        nameInput.setText(""); unitInput.setText("");
        refresh(); toast("تم حفظ الصنف");
    }

    void addMovement() {
        String q = qtyInput.getText().toString().trim();
        if (q.isEmpty()) { toast("أدخل الكمية"); return; }
        double amount;
        try { amount = Double.parseDouble(q); } catch(Exception e) { toast("الكمية غير صحيحة"); return; }
        if (amount <= 0) { toast("يجب أن تكون الكمية أكبر من صفر"); return; }

        Cursor c = db.items();
        String[] names = new String[c.getCount()];
        int i=0; while(c.moveToNext()) names[i++] = c.getString(1); c.close();
        if (names.length == 0) { toast("أضف صنفاً أولاً"); return; }

        new AlertDialog.Builder(this).setTitle("اختر الصنف")
            .setItems(names, (d, which) -> {
                int id = db.findItem(names[which]);
                boolean incoming = typeSpinner.getSelectedItemPosition() == 0;
                if (!incoming && db.balance(id) < amount) {
                    toast("الكمية الخارجة أكبر من الرصيد"); return;
                }
                db.move(id, incoming ? amount : -amount, selectedDate());
                qtyInput.setText(""); refresh();
                toast(incoming ? "تم تسجيل الوارد" : "تم تسجيل الصادر");
            }).show();
    }

    void refresh() {
        if (itemsBox == null) return;
        itemsBox.removeAllViews();
        Cursor c = db.items();
        int count = c.getCount();
        totalText.setText("عدد الأصناف: " + count);
        while(c.moveToNext()) {
            int id = c.getInt(0);
            String name = c.getString(1), unit = c.getString(2);
            double bal = db.balance(id);
            TextView row = text(name + "\nالوحدة: " + unit + "     الرصيد: " +
                String.format(Locale.getDefault(), "%s", bal), 16, true);
            row.setBackgroundColor(0xFFFFFFFF);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(5), 0, dp(5));
            itemsBox.addView(row, lp);
        }
        c.close();
        refreshHistory();
    }

    void refreshHistory() {
        historyBox.removeAllViews();
        Cursor h = db.history();
        if (!h.moveToFirst()) {
            historyBox.addView(text("لا توجد حركات مسجلة حتى الآن", 14, false));
        } else {
            do {
                String name = h.getString(0);
                String unit = h.getString(1);
                double qty = h.getDouble(2);
                String date = h.getString(3);
                boolean incoming = qty >= 0;
                String label = incoming ? "وارد +" : "صادر -";
                TextView row = text(name + "\n" + label + " " +
                    String.format(Locale.getDefault(), "%s", Math.abs(qty)) + " " + unit +
                    "\nالتاريخ: " + date, 15, true);
                row.setBackgroundColor(incoming ? 0xFFE8F5E9 : 0xFFFFEBEE);
                row.setPadding(dp(12), dp(10), dp(12), dp(10));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.setMargins(0, dp(4), 0, dp(4));
                historyBox.addView(row, lp);
            } while (h.moveToNext());
        }
        h.close();
    }


    String htmlEscape(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace("\"", "&quot;")
            .replace("'", "&#39;");
    }

    void exportPdf() {
        StringBuilder html = new StringBuilder();
        html.append("<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'>")
            .append("<style>body{font-family:sans-serif;direction:rtl;text-align:right;color:#17324d;padding:22px}")
            .append("h1,h2{text-align:center;color:#087e8b}table{width:100%;border-collapse:collapse;margin:12px 0 24px}")
            .append("th,td{border:1px solid #9aa8b5;padding:8px;text-align:right}th{background:#e1f3f2}")
            .append(".out{color:#b3261e}.in{color:#16713a}.date{font-size:12px;color:#555}</style></head><body>")
            .append("<h1>مخزني</h1><h2>تقرير الأصناف والأرصدة</h2>")
            .append("<p class='date'>تاريخ إعداد التقرير: ")
            .append(new java.text.SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.getDefault()).format(new java.util.Date()))
            .append("</p><table><tr><th>الصنف</th><th>الوحدة</th><th>الرصيد</th></tr>");

        Cursor itemsCursor = db.items();
        while (itemsCursor.moveToNext()) {
            int id = itemsCursor.getInt(0);
            html.append("<tr><td>").append(htmlEscape(itemsCursor.getString(1)))
                .append("</td><td>").append(htmlEscape(itemsCursor.getString(2)))
                .append("</td><td>").append(String.format(Locale.getDefault(), "%s", db.balance(id)))
                .append("</td></tr>");
        }
        itemsCursor.close();
        html.append("</table><h2>سجل الحركات (الوارد والصادر)</h2>")
            .append("<table><tr><th>الصنف</th><th>نوع الحركة</th><th>الكمية</th><th>الوحدة</th><th>التاريخ</th></tr>");
        Cursor historyCursor = db.history();
        while (historyCursor.moveToNext()) {
            String item = historyCursor.getString(0);
            String unit = historyCursor.getString(1);
            double quantity = historyCursor.getDouble(2);
            String date = historyCursor.getString(3);
            boolean incoming = quantity >= 0;
            html.append("<tr><td>").append(htmlEscape(item)).append("</td><td class='")
                .append(incoming ? "in'>وارد" : "out'>صادر")
                .append("</td><td>").append(String.format(Locale.getDefault(), "%s", Math.abs(quantity)))
                .append("</td><td>").append(htmlEscape(unit)).append("</td><td>")
                .append(htmlEscape(date)).append("</td></tr>");
        }
        historyCursor.close();
        html.append("</table></body></html>");

        pdfWebView = new WebView(this);
        pdfWebView.getSettings().setJavaScriptEnabled(false);
        pdfWebView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                android.print.PrintDocumentAdapter adapter = view.createPrintDocumentAdapter("Makhzani-Report");
                printManager.print("تقرير مخزني", adapter, new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                pdfWebView = null;
            }
        });
        pdfWebView.loadDataWithBaseURL(null, html.toString(), "text/html", "UTF-8", null);
        toast("اختر حفظ بصيغة PDF من شاشة الطباعة");
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    class DB extends SQLiteOpenHelper {
        DB() { super(MainActivity.this, "makhzani.db", null, 2); }
        public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, unit TEXT)");
            d.execSQL("CREATE TABLE movements(id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER, qty REAL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, movement_date TEXT)");
        }
        public void onUpgrade(SQLiteDatabase d, int oldV, int newV) {
            if (oldV < 2) d.execSQL("ALTER TABLE movements ADD COLUMN movement_date TEXT");
        }
        void addItem(String n, String u) {
            ContentValues v = new ContentValues(); v.put("name", n); v.put("unit", u);
            getWritableDatabase().insert("items", null, v);
        }
        int findItem(String n) {
            Cursor c = getReadableDatabase().rawQuery("SELECT id FROM items WHERE name=?", new String[]{n});
            int id = c.moveToFirst() ? c.getInt(0) : -1; c.close(); return id;
        }
        Cursor items() { return getReadableDatabase().rawQuery("SELECT id,name,unit FROM items ORDER BY name", null); }
        void move(int id, double q, String date) {
            ContentValues v = new ContentValues();
            v.put("item_id", id); v.put("qty", q); v.put("movement_date", date);
            getWritableDatabase().insert("movements", null, v);
        }
        double balance(int id) {
            Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(qty),0) FROM movements WHERE item_id=?", new String[]{String.valueOf(id)});
            double x = c.moveToFirst() ? c.getDouble(0) : 0; c.close(); return x;
        }
        Cursor history() {
            return getReadableDatabase().rawQuery(
                "SELECT i.name,i.unit,m.qty,COALESCE(m.movement_date, date(m.created_at)) " +
                "FROM movements m JOIN items i ON i.id=m.item_id ORDER BY COALESCE(m.movement_date,date(m.created_at)) DESC,m.id DESC", null);
        }
    }
}
