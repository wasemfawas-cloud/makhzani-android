package com.wasemfawas.makhzani;

import android.app.*;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db;
    LinearLayout page, itemsBox;
    EditText nameInput, unitInput, qtyInput;
    Spinner typeSpinner;
    TextView totalText;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB();
        buildUI();
        refresh();
    }

    int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }

    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size);
        t.setTextColor(0xFF17324D);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(4), dp(6), dp(4), dp(6));
        return t;
    }

    EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setSingleLine(true); e.setTextSize(16);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        return e;
    }

    Button button(String label) {
        Button b = new Button(this); b.setText(label);
        return b;
    }

    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(18), dp(16), dp(24));
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        page.setBackgroundColor(0xFFF4F7FA);
        scroll.addView(page);
        setContentView(scroll);

        TextView title = text("مخزني", 28, true);
        title.setTextColor(0xFF087E8B);
        page.addView(title);
        page.addView(text("إدارة الأصناف والكميات الداخلة والخارجة", 14, false));

        totalText = text("عدد الأصناف: 0", 18, true);
        totalText.setBackgroundColor(0xFFE1F3F2);
        totalText.setPadding(dp(12), dp(12), dp(12), dp(12));
        page.addView(totalText);

        page.addView(text("إضافة صنف جديد", 20, true));
        nameInput = input("اسم الصنف");
        unitInput = input("الوحدة (قطعة، كرتون، كيس، كيلو...)");
        page.addView(nameInput); page.addView(unitInput);
        page.addView(button("حفظ الصنف") {{ setOnClickListener(v -> addItem()); }});

        page.addView(text("تسجيل حركة مخزنية", 20, true));
        typeSpinner = new Spinner(this);
        String[] types = {"وارد", "صادر"};
        typeSpinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, types));
        page.addView(typeSpinner);
        qtyInput = input("الكمية");
        page.addView(qtyInput);
        page.addView(button("تسجيل الحركة") {{ setOnClickListener(v -> addMovement()); }});

        page.addView(text("الأصناف والأرصدة", 20, true));
        itemsBox = new LinearLayout(this);
        itemsBox.setOrientation(LinearLayout.VERTICAL);
        page.addView(itemsBox);
        page.addView(button("تحديث القائمة") {{ setOnClickListener(v -> refresh()); }});
    }

    void addItem() {
        String name = nameInput.getText().toString().trim();
        String unit = unitInput.getText().toString().trim();
        if (name.isEmpty() || unit.isEmpty()) {
            toast("أدخل اسم الصنف والوحدة"); return;
        }
        if (db.findItem(name) != -1) { toast("هذا الصنف موجود بالفعل"); return; }
        db.addItem(name, unit);
        nameInput.setText(""); unitInput.setText("");
        refresh(); toast("تم حفظ الصنف");
    }

    void addMovement() {
        String q = qtyInput.getText().toString().trim();
        if (q.isEmpty()) { toast("أدخل الكمية"); return; }
        double amount;
        try { amount = Double.parseDouble(q); } catch(Exception e) { toast("الكمية غير صحيحة"); return; }
        if (amount <= 0) { toast("يجب أن تكون الكمية أكبر من صفر"); return; }

        Cursor c = db.items();
        String[] names = new String[c.getCount()];
        int i=0; while(c.moveToNext()) names[i++] = c.getString(1); c.close();
        if (names.length == 0) { toast("أضف صنفاً أولاً"); return; }

        new AlertDialog.Builder(this).setTitle("اختر الصنف")
            .setItems(names, (d, which) -> {
                int id = db.findItem(names[which]);
                boolean incoming = typeSpinner.getSelectedItemPosition() == 0;
                if (!incoming && db.balance(id) < amount) {
                    toast("الكمية الخارجة أكبر من الرصيد"); return;
                }
                db.move(id, incoming ? amount : -amount);
                qtyInput.setText(""); refresh();
                toast("تم تسجيل الحركة");
            }).show();
    }

    void refresh() {
        if (itemsBox == null) return;
        itemsBox.removeAllViews();
        Cursor c = db.items();
        int count = c.getCount();
        totalText.setText("عدد الأصناف: " + count);
        while(c.moveToNext()) {
            int id = c.getInt(0);
            String name = c.getString(1), unit = c.getString(2);
            double bal = db.balance(id);
            TextView row = text(name + "\nالوحدة: " + unit + "     الرصيد: " +
                String.format(Locale.getDefault(), "%s", bal), 16, true);
            row.setBackgroundColor(0xFFFFFFFF);
            row.setPadding(dp(14), dp(12), dp(14), dp(12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(5), 0, dp(5));
            itemsBox.addView(row, lp);
        }
        c.close();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    class DB extends SQLiteOpenHelper {
        DB() { super(MainActivity.this, "makhzani.db", null, 1); }
        public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, unit TEXT)");
            d.execSQL("CREATE TABLE movements(id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER, qty REAL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        }
        public void onUpgrade(SQLiteDatabase d, int oldV, int newV) {}
        void addItem(String n, String u) {
            ContentValues v = new ContentValues(); v.put("name", n); v.put("unit", u);
            getWritableDatabase().insert("items", null, v);
        }
        int findItem(String n) {
            Cursor c = getReadableDatabase().rawQuery("SELECT id FROM items WHERE name=?", new String[]{n});
            int id = c.moveToFirst() ? c.getInt(0) : -1; c.close(); return id;
        }
        Cursor items() { return getReadableDatabase().rawQuery("SELECT id,name,unit FROM items ORDER BY name", null); }
        void move(int id, double q) {
            ContentValues v = new ContentValues(); v.put("item_id", id); v.put("qty", q);
            getWritableDatabase().insert("movements", null, v);
        }
        double balance(int id) {
            Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(qty),0) FROM movements WHERE item_id=?", new String[]{String.valueOf(id)});
            double x = c.moveToFirst() ? c.getDouble(0) : 0; c.close(); return x;
        }
    }
}
