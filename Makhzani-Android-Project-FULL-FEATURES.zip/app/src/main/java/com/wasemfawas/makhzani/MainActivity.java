package com.wasemfawas.makhzani;

import android.app.*;
import android.os.Bundle;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout page, itemsBox; EditText nameInput, unitInput, qtyInput, minInput; Spinner typeSpinner; TextView totalText;
    String selectedDate;
    final SimpleDateFormat dateFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    final int NOTIF_ID = 1001;

    @Override public void onCreate(Bundle b) { super.onCreate(b); db=new DB(); createNotificationChannel(); if(android.os.Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},77); buildUI(); refresh(); }
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xFF17324D);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(4),dp(6),dp(4),dp(6));return t;}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(16);e.setPadding(dp(12),dp(8),dp(12),dp(8));return e;}
    Button button(String label){Button b=new Button(this);b.setText(label);return b;}

    void buildUI(){
        ScrollView scroll=new ScrollView(this); page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(16),dp(18),dp(16),dp(24)); page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); page.setBackgroundColor(0xFFF4F7FA); scroll.addView(page); setContentView(scroll);
        TextView title=text("مخزني",28,true); title.setTextColor(0xFF087E8B); page.addView(title); page.addView(text("إدارة الأصناف والكميات الداخلة والخارجة",14,false));
        totalText=text("عدد الأصناف: 0",18,true); totalText.setBackgroundColor(0xFFE1F3F2); totalText.setPadding(dp(12),dp(12),dp(12),dp(12)); page.addView(totalText);
        page.addView(text("إضافة صنف جديد",20,true)); nameInput=input("اسم الصنف"); unitInput=input("الوحدة (قطعة، كرتون، كيس، كيلو...)"); minInput=input("الحد الأدنى للتنبيه (اختياري)"); minInput.setInputType(2|8192); page.addView(nameInput); page.addView(unitInput); page.addView(minInput);
        Button save=button("حفظ الصنف"); save.setOnClickListener(v->addItem()); page.addView(save);
        page.addView(text("تسجيل حركة مخزنية",20,true)); typeSpinner=new Spinner(this); typeSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"وارد","صادر"})); page.addView(typeSpinner);
        qtyInput=input("الكمية"); qtyInput.setInputType(2|8192); page.addView(qtyInput);
        Button dateButton=button("تاريخ الحركة: اليوم"); selectedDate=dateFmt.format(new Date()); dateButton.setOnClickListener(v->pickDate(dateButton)); page.addView(dateButton);
        Button movement=button("تسجيل الحركة"); movement.setOnClickListener(v->addMovement()); page.addView(movement);
        page.addView(text("الأصناف والأرصدة",20,true)); itemsBox=new LinearLayout(this); itemsBox.setOrientation(LinearLayout.VERTICAL); page.addView(itemsBox);
        Button history=button("سجل الحركات"); history.setOnClickListener(v->showHistory()); page.addView(history);
        Button pdf=button("تصدير تقرير PDF"); pdf.setOnClickListener(v->exportPdf()); page.addView(pdf);
        Button refresh=button("تحديث القائمة"); refresh.setOnClickListener(v->refresh()); page.addView(refresh);
    }
    void pickDate(Button b){Calendar c=Calendar.getInstance(); try{c.setTime(dateFmt.parse(selectedDate));}catch(Exception ignored){} new DatePickerDialog(this,(v,y,m,d)->{Calendar x=Calendar.getInstance();x.set(y,m,d);selectedDate=dateFmt.format(x.getTime());b.setText("تاريخ الحركة: "+selectedDate);},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    void addItem(){String n=nameInput.getText().toString().trim(),u=unitInput.getText().toString().trim(),m=minInput.getText().toString().trim(); if(n.isEmpty()||u.isEmpty()){toast("أدخل اسم الصنف والوحدة");return;} if(db.findItem(n)!=-1){toast("هذا الصنف موجود بالفعل");return;} double min=0; if(!m.isEmpty())try{min=Double.parseDouble(m);}catch(Exception e){toast("الحد الأدنى غير صحيح");return;} if(min<0){toast("الحد الأدنى لا يمكن أن يكون سالباً");return;} db.addItem(n,u,min); nameInput.setText("");unitInput.setText("");minInput.setText("");refresh();toast("تم حفظ الصنف");}
    void addMovement(){String q=qtyInput.getText().toString().trim(); if(q.isEmpty()){toast("أدخل الكمية");return;} double amount;try{amount=Double.parseDouble(q);}catch(Exception e){toast("الكمية غير صحيحة");return;} if(amount<=0){toast("يجب أن تكون الكمية أكبر من صفر");return;} Cursor c=db.items(); String[] names=new String[c.getCount()];int i=0;while(c.moveToNext())names[i++]=c.getString(1);c.close();if(names.length==0){toast("أضف صنفاً أولاً");return;} new AlertDialog.Builder(this).setTitle("اختر الصنف").setItems(names,(d,w)->{int id=db.findItem(names[w]);boolean incoming=typeSpinner.getSelectedItemPosition()==0;if(!incoming&&db.balance(id)<amount){toast("الكمية الخارجة أكبر من الرصيد");return;}db.move(id,incoming?amount:-amount,selectedDate);qtyInput.setText("");refresh();toast("تم تسجيل الحركة بتاريخ "+selectedDate);}).show();}
    void refresh(){if(itemsBox==null)return;itemsBox.removeAllViews();Cursor c=db.items();int count=c.getCount();totalText.setText("عدد الأصناف: "+count);while(c.moveToNext()){int id=c.getInt(0);String name=c.getString(1),unit=c.getString(2);double bal=db.balance(id),min=db.min(id);String status=min>0&&bal<=min?"\n⚠️ وصل للحد الأدنى ("+min+")":"";TextView row=text(name+"\nالوحدة: "+unit+"     الرصيد: "+fmt(bal)+status,16,true);row.setBackgroundColor(0xFFFFFFFF);row.setPadding(dp(14),dp(12),dp(14),dp(12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));itemsBox.addView(row,lp);if(min>0&&bal<=min)sendLowStockNotification(name,bal,min);}c.close();}
    String fmt(double x){return String.format(Locale.getDefault(),"%.2f",x).replaceAll("\\.00$","");}
    void showHistory(){Cursor c=db.history();StringBuilder s=new StringBuilder();while(c.moveToNext()){s.append(c.getString(4)).append(" — ").append(c.getString(1)).append(" — ").append(c.getDouble(2)>0?"وارد":"صادر").append(" ").append(fmt(Math.abs(c.getDouble(2)))).append(" ").append(c.getString(3)).append("\n");}c.close();if(s.length()==0)s.append("لا توجد حركات مسجلة");new AlertDialog.Builder(this).setTitle("سجل الحركات").setMessage(s.toString()).setPositiveButton("إغلاق",null).show();}
    void exportPdf(){Cursor items=db.items();StringBuilder html=new StringBuilder("<html dir='rtl'><meta charset='utf-8'><body style='font-family:sans-serif'><h1>تقرير مخزني</h1><p>التاريخ: "+dateFmt.format(new Date())+"</p><table border='1' cellpadding='8' cellspacing='0' width='100%'><tr><th>الصنف</th><th>الوحدة</th><th>الرصيد</th><th>الحد الأدنى</th></tr>");while(items.moveToNext()){int id=items.getInt(0);html.append("<tr><td>").append(items.getString(1)).append("</td><td>").append(items.getString(2)).append("</td><td>").append(fmt(db.balance(id))).append("</td><td>").append(fmt(db.min(id))).append("</td></tr>");}items.close();html.append("</table><h2>الحركات</h2><p>");Cursor h=db.history();while(h.moveToNext())html.append(h.getString(4)).append(" — ").append(h.getString(1)).append(" — ").append(h.getDouble(2)>0?"وارد":"صادر").append(" ").append(fmt(Math.abs(h.getDouble(2)))).append(" ").append(h.getString(3)).append("<br>");h.close();html.append("</p></body></html>");final WebView w=new WebView(this);w.setWebViewClient(new WebViewClient(){public void onPageFinished(WebView v,String u){PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);PrintDocumentAdapter a=v.createPrintDocumentAdapter("Makhzani-Report");pm.print("Makhzani-Report",a,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());}});w.loadDataWithBaseURL(null,html.toString(),"text/html","UTF-8",null);}
    void createNotificationChannel(){if(android.os.Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("low_stock","تنبيهات المخزون",NotificationManager.IMPORTANCE_DEFAULT);ch.setDescription("تنبيه عند وصول الصنف للحد الأدنى");getSystemService(NotificationManager.class).createNotificationChannel(ch);}}
    void sendLowStockNotification(String name,double bal,double min){if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)return;android.app.Notification.Builder b=android.os.Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,"low_stock"):new android.app.Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("تنبيه مخزون منخفض").setContentText(name+" وصل إلى "+fmt(bal)+" (الحد الأدنى "+fmt(min)+")").setAutoCancel(true);getSystemService(NotificationManager.class).notify(NOTIF_ID+name.hashCode(),b.build());}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    class DB extends SQLiteOpenHelper{
        DB(){super(MainActivity.this,"makhzani.db",null,2);} public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,unit TEXT,min_qty REAL DEFAULT 0)");d.execSQL("CREATE TABLE movements(id INTEGER PRIMARY KEY AUTOINCREMENT,item_id INTEGER,qty REAL,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,movement_date TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV){if(oldV<2){d.execSQL("ALTER TABLE items ADD COLUMN min_qty REAL DEFAULT 0");d.execSQL("ALTER TABLE movements ADD COLUMN movement_date TEXT");d.execSQL("UPDATE movements SET movement_date=date(created_at) WHERE movement_date IS NULL");}}
        void addItem(String n,String u,double min){ContentValues v=new ContentValues();v.put("name",n);v.put("unit",u);v.put("min_qty",min);getWritableDatabase().insert("items",null,v);} int findItem(String n){Cursor c=getReadableDatabase().rawQuery("SELECT id FROM items WHERE name=?",new String[]{n});int id=c.moveToFirst()?c.getInt(0):-1;c.close();return id;} Cursor items(){return getReadableDatabase().rawQuery("SELECT id,name,unit,min_qty FROM items ORDER BY name",null);} void move(int id,double q,String date){ContentValues v=new ContentValues();v.put("item_id",id);v.put("qty",q);v.put("movement_date",date);getWritableDatabase().insert("movements",null,v);} double balance(int id){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(qty),0) FROM movements WHERE item_id=?",new String[]{String.valueOf(id)});double x=c.moveToFirst()?c.getDouble(0):0;c.close();return x;} double min(int id){Cursor c=getReadableDatabase().rawQuery("SELECT min_qty FROM items WHERE id=?",new String[]{String.valueOf(id)});double x=c.moveToFirst()?c.getDouble(0):0;c.close();return x;} Cursor history(){return getReadableDatabase().rawQuery("SELECT m.id,i.name,m.qty,i.unit,COALESCE(m.movement_date,date(m.created_at)) FROM movements m JOIN items i ON i.id=m.item_id ORDER BY COALESCE(m.movement_date,m.created_at) DESC,m.id DESC",null);}
    }
}
