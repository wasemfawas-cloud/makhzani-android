package com.wasemfawas.makhzani;

import android.app.*;
import android.os.Bundle;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import java.io.*;
import org.json.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout page, itemsBox; EditText nameInput, unitInput, qtyInput, minInput; Spinner typeSpinner; TextView totalText; CheckBox alertCheck;
    String selectedDate;
    final SimpleDateFormat dateFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    final int NOTIF_ID = 1001;
    static final int REQ_BACKUP = 501;
    static final int REQ_RESTORE = 502;

    @Override public void onCreate(Bundle b) { super.onCreate(b); db=new DB(); createNotificationChannel(); if(android.os.Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},77); buildUI(); refresh(); }
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xFF17324D);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(4),dp(6),dp(4),dp(6));return t;}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(16);e.setPadding(dp(12),dp(8),dp(12),dp(8));return e;}
    Button button(String label){Button b=new Button(this);b.setText(label);return b;}

    void buildUI(){
        ScrollView scroll=new ScrollView(this); page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(16),dp(18),dp(16),dp(24)); page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); page.setBackgroundColor(0xFFF4F7FA); scroll.addView(page); setContentView(scroll);
        TextView title=text("مخزني",28,true); title.setTextColor(0xFF087E8B); page.addView(title); page.addView(text("إدارة الأصناف والكميات الداخلة والخارجة",14,false));
        totalText=text("عدد الأصناف: 0",18,true); totalText.setBackgroundColor(0xFFE1F3F2); totalText.setPadding(dp(12),dp(12),dp(12),dp(12)); page.addView(totalText);
        page.addView(text("إضافة صنف جديد",20,true)); nameInput=input("اسم الصنف"); unitInput=input("الوحدة (قطعة، كرتون، كيس، كيلو...)"); minInput=input("الحد الأدنى للتنبيه (مثلاً 5)"); minInput.setInputType(2|8192); page.addView(nameInput); page.addView(unitInput); page.addView(minInput); alertCheck=new CheckBox(this); alertCheck.setText("🔔 تفعيل تنبيه المخزون المنخفض"); alertCheck.setTextSize(16); alertCheck.setChecked(getPreferences(MODE_PRIVATE).getBoolean("low_alerts",true)); alertCheck.setOnCheckedChangeListener((b,checked)->getPreferences(MODE_PRIVATE).edit().putBoolean("low_alerts",checked).apply()); page.addView(alertCheck); Button testAlert=button("اختبار التنبيه"); testAlert.setOnClickListener(v->testNotification()); page.addView(testAlert);
        Button save=button("حفظ الصنف"); save.setOnClickListener(v->addItem()); page.addView(save);
        page.addView(text("تسجيل حركة مخزنية",20,true)); typeSpinner=new Spinner(this); typeSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"وارد","صادر"})); page.addView(typeSpinner);
        qtyInput=input("الكمية"); qtyInput.setInputType(2|8192); page.addView(qtyInput);
        Button dateButton=button("تاريخ الحركة: اليوم"); selectedDate=dateFmt.format(new Date()); dateButton.setOnClickListener(v->pickDate(dateButton)); page.addView(dateButton);
        Button movement=button("تسجيل الحركة"); movement.setOnClickListener(v->addMovement()); page.addView(movement);
        page.addView(text("الأصناف والأرصدة",20,true)); itemsBox=new LinearLayout(this); itemsBox.setOrientation(LinearLayout.VERTICAL); page.addView(itemsBox);
        Button history=button("سجل الحركات"); history.setOnClickListener(v->showHistory()); page.addView(history);
        Button pdf=button("📄 تقرير جرد شهري PDF"); pdf.setOnClickListener(v->chooseReportMonth()); page.addView(pdf);
        page.addView(text("نسخ البيانات وحمايتها",20,true));
        Button backup=button("💾 نسخ البيانات إلى الهاتف"); backup.setOnClickListener(v->chooseBackupFile()); page.addView(backup);
        Button restore=button("♻️ استعادة البيانات من الهاتف"); restore.setOnClickListener(v->chooseRestoreFile()); page.addView(restore);
        page.addView(text("مهم: احفظ ملف النسخة الاحتياطية خارج التطبيق. عند حذف التطبيق تبقى النسخة على الهاتف ويمكن استعادتها بعد إعادة التثبيت.",13,false));
        Button refresh=button("تحديث القائمة"); refresh.setOnClickListener(v->refresh()); page.addView(refresh);
    }
    void pickDate(Button b){Calendar c=Calendar.getInstance(); try{c.setTime(dateFmt.parse(selectedDate));}catch(Exception ignored){} new DatePickerDialog(this,(v,y,m,d)->{Calendar x=Calendar.getInstance();x.set(y,m,d);selectedDate=dateFmt.format(x.getTime());b.setText("تاريخ الحركة: "+selectedDate);},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    void addItem(){String n=nameInput.getText().toString().trim(),u=unitInput.getText().toString().trim(),m=minInput.getText().toString().trim(); if(n.isEmpty()||u.isEmpty()){toast("أدخل اسم الصنف والوحدة");return;} if(db.findItem(n)!=-1){toast("هذا الصنف موجود بالفعل");return;} double min=0; if(!m.isEmpty())try{min=Double.parseDouble(m);}catch(Exception e){toast("الحد الأدنى غير صحيح");return;} if(min<0){toast("الحد الأدنى لا يمكن أن يكون سالباً");return;} db.addItem(n,u,min); nameInput.setText("");unitInput.setText("");minInput.setText("");refresh();toast("تم حفظ الصنف");}
    void addMovement(){String q=qtyInput.getText().toString().trim(); if(q.isEmpty()){toast("أدخل الكمية");return;} double amount;try{amount=Double.parseDouble(q);}catch(Exception e){toast("الكمية غير صحيحة");return;} if(amount<=0){toast("يجب أن تكون الكمية أكبر من صفر");return;} Cursor c=db.items(); String[] names=new String[c.getCount()];int i=0;while(c.moveToNext())names[i++]=c.getString(1);c.close();if(names.length==0){toast("أضف صنفاً أولاً");return;} new AlertDialog.Builder(this).setTitle("اختر الصنف").setItems(names,(d,w)->{int id=db.findItem(names[w]);boolean incoming=typeSpinner.getSelectedItemPosition()==0;if(!incoming&&db.balance(id)<amount){toast("الكمية الخارجة أكبر من الرصيد");return;}db.move(id,incoming?amount:-amount,selectedDate);qtyInput.setText("");refresh(); if(getPreferences(MODE_PRIVATE).getBoolean("low_alerts",true)){double newBal=db.balance(id), min=db.min(id); if(min>0&&newBal<=min) sendLowStockNotification(names[w],newBal,min);} toast("تم تسجيل الحركة بتاريخ "+selectedDate);}).show();}
    void refresh(){if(itemsBox==null)return;itemsBox.removeAllViews();Cursor c=db.items();int count=c.getCount();totalText.setText("عدد الأصناف: "+count);while(c.moveToNext()){int id=c.getInt(0);String name=c.getString(1),unit=c.getString(2);double bal=db.balance(id),min=db.min(id);String status=min>0&&bal<=min?"\n⚠️ وصل للحد الأدنى ("+min+")":"";TextView row=text(name+"\nالوحدة: "+unit+"     الرصيد: "+fmt(bal)+status,16,true);row.setBackgroundColor(0xFFFFFFFF);row.setPadding(dp(14),dp(12),dp(14),dp(12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));itemsBox.addView(row,lp);if(min>0&&bal<=min&&getPreferences(MODE_PRIVATE).getBoolean("low_alerts",true)){}}c.close();}
    String fmt(double x){return String.format(Locale.getDefault(),"%.2f",x).replaceAll("\\.00$","");}
    void showHistory(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(8),dp(4),dp(8),dp(4)); box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView scroll=new ScrollView(this); scroll.addView(box);
        Cursor c=db.history(); String lastDate="";
        while(c.moveToNext()){
            String rawDate=c.getString(4); String shownDate=displayDate(rawDate);
            if(!shownDate.equals(lastDate)){
                TextView date=text(shownDate,17,true); date.setTextColor(0xFF087E8B); date.setGravity(Gravity.CENTER); date.setBackgroundColor(0xFFE1F3F2); date.setPadding(dp(8),dp(9),dp(8),dp(9));
                box.addView(date,new LinearLayout.LayoutParams(-1,dp(42)));
                lastDate=shownDate;
            }
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(6),dp(7),dp(6),dp(7)); row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            TextView item=text(c.getString(1),16,true); item.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            TextView type=text(c.getDouble(2)>0?"وارد":"صادر",15,false); type.setGravity(Gravity.CENTER);
            TextView amount=text((c.getDouble(2)>0?"+":"-")+fmt(Math.abs(c.getDouble(2)))+" "+c.getString(3),16,true); amount.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
            row.addView(item,new LinearLayout.LayoutParams(0,dp(48),1.35f)); row.addView(type,new LinearLayout.LayoutParams(0,dp(48),0.8f)); row.addView(amount,new LinearLayout.LayoutParams(0,dp(48),1.15f));
            box.addView(row);
            View line=new View(this); line.setBackgroundColor(0xFFE0E0E0); box.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        }
        c.close();
        if(box.getChildCount()==0){TextView empty=text("لا توجد حركات مسجلة",17,false); empty.setGravity(Gravity.CENTER); box.addView(empty,new LinearLayout.LayoutParams(-1,dp(80)));}
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("سجل الحركات").setView(scroll).setPositiveButton("إغلاق",null).create(); dialog.show();
    }
    String displayDate(String raw){try{return new SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).parse(raw));}catch(Exception e){return raw;}}
    void chooseReportMonth(){
        Calendar now=Calendar.getInstance();
        final String[] values=new String[12];
        final String[] labels=new String[12];
        Locale ar=new Locale("ar");
        SimpleDateFormat ym=new SimpleDateFormat("yyyy-MM",Locale.getDefault());
        SimpleDateFormat labelFmt=new SimpleDateFormat("MMMM yyyy",ar);
        Calendar c=(Calendar)now.clone();
        for(int i=0;i<12;i++){
            values[i]=ym.format(c.getTime());
            labels[i]=labelFmt.format(c.getTime());
            c.add(Calendar.MONTH,-1);
        }
        new AlertDialog.Builder(this).setTitle("اختر شهر تقرير الجرد").setItems(labels,(d,w)->exportMonthlyPdf(values[w])).setNegativeButton("إلغاء",null).show();
    }

    String esc(String s){return s==null?"":s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}

    void exportMonthlyPdf(String ym){
        try{
            SimpleDateFormat monthFmt=new SimpleDateFormat("yyyy-MM",Locale.getDefault());
            Date parsed=monthFmt.parse(ym);
            Calendar cal=Calendar.getInstance(); cal.setTime(parsed); cal.set(Calendar.DAY_OF_MONTH,1);
            String first=monthFmt.format(cal.getTime())+"-01";
            cal.add(Calendar.MONTH,1);
            String next=monthFmt.format(cal.getTime())+"-01";
            String monthLabel=new SimpleDateFormat("MMMM yyyy",new Locale("ar")).format(parsed);

            Cursor items=db.items();
            StringBuilder html=new StringBuilder();
            html.append("<html dir='rtl'><meta charset='utf-8'><body style='font-family:sans-serif;color:#17324D;padding:18px'>");
            html.append("<h1 style='text-align:center;color:#087E8B;margin-bottom:4px'>تقرير جرد مخزني</h1>");
            html.append("<h2 style='text-align:center;margin-top:0'>").append(esc(monthLabel)).append("</h2>");
            html.append("<p style='text-align:center'>تقرير يساعدك على معرفة الرصيد قبل الشهر، الحركة خلاله، والرصيد النهائي.</p>");

            HashMap<Integer,Double> running=new HashMap<>();
            int lowCount=0, itemCount=0;
            StringBuilder summary=new StringBuilder("<table border='1' cellpadding='7' cellspacing='0' width='100%' style='border-collapse:collapse;text-align:center'><tr><th>الصنف</th><th>الوحدة</th><th>رصيد أول الشهر</th><th>إجمالي الوارد</th><th>إجمالي الصادر</th><th>الرصيد النهائي</th><th>الحد الأدنى</th><th>الحالة</th></tr>");
            while(items.moveToNext()){
                int id=items.getInt(0); String name=items.getString(1), unit=items.getString(2); double min=db.min(id);
                double opening=db.sumBefore(id,first), incoming=db.sumRange(id,first,next,true), outgoing=db.sumRange(id,first,next,false);
                double closing=opening+incoming-outgoing; running.put(id,opening); itemCount++;
                boolean low=min>0&&closing<=min; if(low)lowCount++;
                String status=low?"⚠️ منخفض":"✓ طبيعي";
                summary.append("<tr><td>").append(esc(name)).append("</td><td>").append(esc(unit)).append("</td><td>").append(fmt(opening)).append("</td><td>").append(fmt(incoming)).append("</td><td>").append(fmt(outgoing)).append("</td><td><b>").append(fmt(closing)).append("</b></td><td>").append(fmt(min)).append("</td><td>").append(status).append("</td></tr>");
            }
            items.close();
            summary.append("</table>");
            html.append("<h2>ملخص الجرد</h2>").append(summary);
            html.append("<p><b>عدد الأصناف:</b> ").append(itemCount).append(" &nbsp;&nbsp; <b>أصناف تحتاج متابعة:</b> ").append(lowCount).append("</p>");

            html.append("<h2 style='margin-top:24px'>كشف الحركة والرصيد بعد كل حركة</h2>");
            html.append("<table border='1' cellpadding='7' cellspacing='0' width='100%' style='border-collapse:collapse;text-align:center'><tr><th>التاريخ</th><th>الصنف</th><th>الحركة</th><th>الكمية</th><th>الرصيد بعد الحركة</th></tr>");
            Cursor h=db.historyForMonth(first,next);
            while(h.moveToNext()){
                int id=h.getInt(0); String date=h.getString(4), name=h.getString(1), unit=h.getString(3); double q=h.getDouble(2);
                double bal=running.containsKey(id)?running.get(id):0; bal+=q; running.put(id,bal);
                String type=q>0?"وارد":"صادر";
                html.append("<tr><td>").append(esc(displayDate(date))).append("</td><td>").append(esc(name)).append("</td><td>").append(type).append("</td><td>").append(fmt(Math.abs(q))).append(" ").append(esc(unit)).append("</td><td><b>").append(fmt(bal)).append(" ").append(esc(unit)).append("</b></td></tr>");
            }
            h.close();
            html.append("</table><p style='margin-top:24px;font-size:12px'>ملاحظة: الرصيد النهائي = رصيد أول الشهر + الوارد − الصادر.</p></body></html>");

            final WebView w=new WebView(this);
            w.setWebViewClient(new WebViewClient(){public void onPageFinished(WebView v,String u){PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);PrintDocumentAdapter a=v.createPrintDocumentAdapter("Makhzani-Report-"+ym);pm.print("Makhzani-Report-"+ym,a,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());}});
            w.loadDataWithBaseURL(null,html.toString(),"text/html","UTF-8",null);
        }catch(Exception e){toast("تعذر إنشاء التقرير: "+e.getMessage());}
    }

    void chooseBackupFile(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE,"Makhzani-Backup-"+dateFmt.format(new Date())+".json");
        startActivityForResult(i,REQ_BACKUP);
    }

    void chooseRestoreFile(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/json");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,REQ_RESTORE);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null || data.getData()==null)return;
        try{
            if(requestCode==REQ_BACKUP) writeBackup(data.getData());
            else if(requestCode==REQ_RESTORE) restoreBackup(data.getData());
        }catch(Exception e){ toast("تعذر تنفيذ العملية: "+e.getMessage()); }
    }

    void writeBackup(Uri uri) throws Exception{
        JSONObject root=new JSONObject();
        root.put("app","Makhzani");
        root.put("version",3);
        root.put("backup_date",dateFmt.format(new Date()));
        JSONArray items=new JSONArray();
        Cursor c=db.items();
        while(c.moveToNext()){
            JSONObject o=new JSONObject();
            o.put("id",c.getInt(0)); o.put("name",c.getString(1)); o.put("unit",c.getString(2)); o.put("min_qty",c.getDouble(3));
            items.put(o);
        }
        c.close();
        JSONArray moves=new JSONArray();
        Cursor h=db.rawMovements();
        while(h.moveToNext()){
            JSONObject o=new JSONObject();
            o.put("item_id",h.getInt(0)); o.put("qty",h.getDouble(1)); o.put("created_at",h.getString(2)); o.put("movement_date",h.getString(3));
            moves.put(o);
        }
        h.close();
        root.put("items",items); root.put("movements",moves);
        try(OutputStream out=getContentResolver().openOutputStream(uri); OutputStreamWriter w=new OutputStreamWriter(out,"UTF-8")){ w.write(root.toString(2)); }
        toast("تم حفظ النسخة الاحتياطية بنجاح");
    }

    void restoreBackup(Uri uri) throws Exception{
        StringBuilder s=new StringBuilder();
        try(InputStream in=getContentResolver().openInputStream(uri); BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"))){String line;while((line=r.readLine())!=null)s.append(line);}
        JSONObject root=new JSONObject(s.toString());
        if(!"Makhzani".equals(root.optString("app")))throw new IllegalArgumentException("ملف النسخة غير صحيح");
        JSONArray items=root.optJSONArray("items"), moves=root.optJSONArray("movements");
        if(items==null||moves==null)throw new IllegalArgumentException("النسخة ناقصة");
        new AlertDialog.Builder(this).setTitle("استعادة البيانات").setMessage("سيتم استبدال البيانات الحالية بالنسخة الاحتياطية. هل تريد المتابعة؟").setNegativeButton("إلغاء",null).setPositiveButton("استعادة",(d,w)->{
            try{db.restore(items,moves);refresh();toast("تمت استعادة البيانات بنجاح");}catch(Exception e){toast("فشلت الاستعادة: "+e.getMessage());}
        }).show();
    }

    void createNotificationChannel(){if(android.os.Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("low_stock","تنبيهات المخزون",NotificationManager.IMPORTANCE_DEFAULT);ch.setDescription("تنبيه عند وصول الصنف للحد الأدنى");getSystemService(NotificationManager.class).createNotificationChannel(ch);}}
    void sendLowStockNotification(String name,double bal,double min){if(!getPreferences(MODE_PRIVATE).getBoolean("low_alerts",true))return; if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED){ if(android.os.Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},77); toast("اسمح بإشعارات مخزني من إعدادات الهاتف لتصل التنبيهات"); return;} android.app.Notification.Builder b=android.os.Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,"low_stock"):new android.app.Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("🔔 تنبيه مخزون منخفض").setContentText(name+" وصل إلى "+fmt(bal)+" (الحد الأدنى "+fmt(min)+")").setAutoCancel(true);getSystemService(NotificationManager.class).notify(NOTIF_ID+Math.abs(name.hashCode()),b.build());}
    void testNotification(){sendLowStockNotification("اختبار التنبيه",0,1); if(android.os.Build.VERSION.SDK_INT>=26){NotificationManager nm=getSystemService(NotificationManager.class); if(!nm.areNotificationsEnabled()) startActivity(new Intent("android.settings.APP_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE",getPackageName()));}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    class DB extends SQLiteOpenHelper{
        DB(){super(MainActivity.this,"makhzani.db",null,3);} public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,unit TEXT,min_qty REAL DEFAULT 0)");d.execSQL("CREATE TABLE movements(id INTEGER PRIMARY KEY AUTOINCREMENT,item_id INTEGER,qty REAL,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,movement_date TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV){if(oldV<2){d.execSQL("ALTER TABLE items ADD COLUMN min_qty REAL DEFAULT 0");d.execSQL("ALTER TABLE movements ADD COLUMN movement_date TEXT");d.execSQL("UPDATE movements SET movement_date=date(created_at) WHERE movement_date IS NULL");}}
        void addItem(String n,String u,double min){ContentValues v=new ContentValues();v.put("name",n);v.put("unit",u);v.put("min_qty",min);getWritableDatabase().insert("items",null,v);} int findItem(String n){Cursor c=getReadableDatabase().rawQuery("SELECT id FROM items WHERE name=?",new String[]{n});int id=c.moveToFirst()?c.getInt(0):-1;c.close();return id;} Cursor items(){return getReadableDatabase().rawQuery("SELECT id,name,unit,min_qty FROM items ORDER BY name",null);} void move(int id,double q,String date){ContentValues v=new ContentValues();v.put("item_id",id);v.put("qty",q);v.put("movement_date",date);getWritableDatabase().insert("movements",null,v);} double balance(int id){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(qty),0) FROM movements WHERE item_id=?",new String[]{String.valueOf(id)});double x=c.moveToFirst()?c.getDouble(0):0;c.close();return x;} double min(int id){Cursor c=getReadableDatabase().rawQuery("SELECT min_qty FROM items WHERE id=?",new String[]{String.valueOf(id)});double x=c.moveToFirst()?c.getDouble(0):0;c.close();return x;} Cursor history(){return getReadableDatabase().rawQuery("SELECT m.id,i.name,m.qty,i.unit,COALESCE(m.movement_date,date(m.created_at)) FROM movements m JOIN items i ON i.id=m.item_id ORDER BY COALESCE(m.movement_date,m.created_at) DESC,m.id DESC",null);}
        double sumBefore(int id,String first){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(qty),0) FROM movements WHERE item_id=? AND COALESCE(movement_date,date(created_at))<?",new String[]{String.valueOf(id),first});double x=c.moveToFirst()?c.getDouble(0):0;c.close();return x;}
        double sumRange(int id,String first,String next,boolean incoming){String op=incoming?">0":"<0";Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM("+(incoming?"qty":"-qty")+"),0) FROM movements WHERE item_id=? AND COALESCE(movement_date,date(created_at))>=? AND COALESCE(movement_date,date(created_at))<? AND qty"+op,new String[]{String.valueOf(id),first,next});double x=c.moveToFirst()?c.getDouble(0):0;c.close();return x;}
        Cursor historyForMonth(String first,String next){return getReadableDatabase().rawQuery("SELECT m.item_id,i.name,m.qty,i.unit,COALESCE(m.movement_date,date(m.created_at)) FROM movements m JOIN items i ON i.id=m.item_id WHERE COALESCE(m.movement_date,date(m.created_at))>=? AND COALESCE(m.movement_date,date(m.created_at))<? ORDER BY COALESCE(m.movement_date,date(m.created_at)) ASC,m.id ASC",new String[]{first,next});}
        Cursor rawMovements(){return getReadableDatabase().rawQuery("SELECT item_id,qty,created_at,movement_date FROM movements ORDER BY id",null);}
        void restore(JSONArray items,JSONArray moves) throws Exception{SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{d.delete("movements",null,null);d.delete("items",null,null);HashMap<Integer,Integer> ids=new HashMap<>();for(int i=0;i<items.length();i++){JSONObject o=items.getJSONObject(i);ContentValues v=new ContentValues();v.put("name",o.getString("name"));v.put("unit",o.getString("unit"));v.put("min_qty",o.optDouble("min_qty",0));long nid=d.insertOrThrow("items",null,v);ids.put(o.getInt("id"),(int)nid);}for(int i=0;i<moves.length();i++){JSONObject o=moves.getJSONObject(i);Integer nid=ids.get(o.getInt("item_id"));if(nid==null)continue;ContentValues v=new ContentValues();v.put("item_id",nid);v.put("qty",o.getDouble("qty"));if(o.has("created_at")&&!o.isNull("created_at"))v.put("created_at",o.getString("created_at"));if(o.has("movement_date")&&!o.isNull("movement_date"))v.put("movement_date",o.getString("movement_date"));d.insertOrThrow("movements",null,v);}d.setTransactionSuccessful();}finally{d.endTransaction();}}
    }
}
